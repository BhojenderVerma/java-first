

public class BinaryString {
    public static void main(String[] args) {
        binaryS(3, 0, "");

    }

    public static void binaryS(int n, int lastPlace, String str ){
        //base case 
        if (n == 0) {
            System.out.println(str);
            return ;
        }
        // kaam 
        binaryS(n-1 ,  0, str + "0");
        if (lastPlace ==0){
            binaryS(n-1,  1, str + "1");
        }

    }
}
