


public class complex {
    int real,imag;

    //default constructor 
    public complex(){

    }
    

    complex(int r , int i ){ // parameterized constructor
        real =r;
        imag= i ;
    }

    public static complex add (complex a, complex b){
        complex c = new complex(0,0);
        c.real= a.real + b.real;
        c.imag = a.imag + b.imag;
        return c ;
    }

    public static complex diff(complex a , complex b){
        complex c = new complex(0,0);
        c.real= a.real - b.real;
        c.imag = a.imag - b.imag;
        return c ;
    }

    public static complex product(complex a , complex b){
        int x = a.real ;
        int y = a.imag;

        int p = b.real;
        int q = b.imag;

        complex c = new complex(0,0);

        c.real= x*p -y*q;
        c.imag= x*q + p*y;
        
        return c;
        
    }

    //print complex number
    public void printComplex(){
        if (real ==0){
            System.out.println(imag+ "i");
        }else if(imag ==0 && real!= 0){
            System.out.println(real);

        }else {
            System.out.println(real + "+"+ imag +"i");
        }
    }
    
    public static void main(String[] args) {
        complex a = new complex(7,8);
        complex b = new complex(2,5);

        complex m = complex.add(a,b);
        m.printComplex();

        complex n = complex.diff(a,b);
        n.printComplex();

        complex o = complex.product(a, b);
        o.printComplex();
    }

}




