public class xPowerN {
    public static void main(String[] args) {
        System.err.println(poow(2,4));
        System.out.println(optimizedPower(2,4));
    }

    //calculate x^n TimeComplexity = O(n)
    public static int poow(int x , int n){
        if (n==1){
            return x;
        }
        return x * poow(x,n-1);
    }

    //calculte x^n with timeComplexity of O(logn)
    public static int optimizedPower(int x, int n){
        if (n==0){
            return 1;
        }
        int halfPower = optimizedPower(x, n/2);
        int halfPowerSq = halfPower * halfPower;
        
        if (n%2 != 0){
            halfPowerSq = x * halfPowerSq;
        }

        return halfPowerSq;
    }
}
