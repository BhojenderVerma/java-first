public class SortedArrayOrNot {
    public static void main(String[] args) {
        int arr[]={5,6};
        System.out.println(isSorted( arr , 0));
    }

    //check whether an array is sorted or not with recursion
    public static boolean isSorted(int arr[] , int i ){
        if (i == arr.length-1){
            return true;
        }
        if (arr[i]>arr[i+1]){
            return false;
        }
        boolean b =  isSorted(arr, i+1);  
        return b;
    }
}
