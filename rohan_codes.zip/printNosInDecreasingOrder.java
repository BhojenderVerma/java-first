class printNosInDecreasingOrder{
    public static void main(String[] args) {
        printDec(10);
        
        printInc(1);
        System.out.println(); 
        printIncre(10);
        
    }
    //descending order 
    public static void printDec(int n){
        if (n==1){
            System.out.println(n);
            return ;
        }
        System.out.print(n + " ");
        
        printDec(n -1);

    }
    //ascending order (my own approach)
    public static void printInc(int n){
        if (n > 1){
            printInc(n-1);
        }
        System.out.print(n + " ");
    }

    //ascending order (ApnaC)
    public static void printIncre(int n ){
        if (n == 1){
            System.out.print(n + " ");
            return ;
        }
        printIncre(n-1);
        System.out.print(n + " ");

    }
}