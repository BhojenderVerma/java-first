public class factorial {
    public static void main(String[] args) {
        System.out.println(fac(5));
        System.out.println(sum(5)); 
    }

    //factorial
    public static int fac(int n){
        if (n == 0){
            return 1;
        }
        return n * fac(n-1);
    }
    //sum of n natural numbers
    public static int sum (int n ){
        if (n == 1){
            return 1;
        }
        int s = n + sum(n-1);
        return s;
    }
}
