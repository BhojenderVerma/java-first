public class BinarySearch {
  public static void main(String[] args) {
      
    int arr[]={22,34,543,789,65};
    int key = 22;
    boolean a= binarysearch(arr, key);

    if (a ==false){
        System.err.println("not found");
    }else{
        System.out.println("found");
    }
  }

  public static boolean binarysearch(int arr[], int key){
    int s = 0, e=arr.length-1;
    while (s<=e){
        int mid = (s+e)/2;
        if (key ==arr[mid] ){
            return true;
        }
        else if (key>arr[mid]){
            s= mid +1;
        }else {
            e = mid -1;
        }
    }
    return false;
  }

}
