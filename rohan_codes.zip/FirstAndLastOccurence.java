public class FirstAndLastOccurence {
    public static void main(String[] args) {
        int arr[]={2,3,7,6,4,5,3};
        System.err.println(firstOccurence(arr, 0, 5));
        System.err.println(lastOccurence(arr, arr.length-1, 2));
        System.err.println(lastOccurenceAC(arr, 3, 0));

    }
    public static int firstOccurence(int arr[], int i, int key){
        if (i == arr.length){
            return -1;
        }
        if (arr[i]== key){
            return i;
        }
        return firstOccurence(arr, i+1, key);
    }
    //last occurence of an element in an array (Own Approach)
    public  static int lastOccurence(int arr[],int i , int key){
        if (i == -1){
            return -1;
        }
        if (arr[i]==key){
            return i;
        }
        return lastOccurence(arr, i-1, key);
    }

    //ApnaC Approach
    public static int lastOccurenceAC(int arr[], int key, int i){
        if (i==arr.length){
            return -1;
        }
        int isFound  = lastOccurenceAC(arr, key, i+1);

        if (isFound == -1 && arr[i]==key){
            return i;
        }
        
        return isFound;
    }
}
